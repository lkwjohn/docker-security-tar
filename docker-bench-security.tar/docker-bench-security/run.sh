#!/bin/sh
 
CURRENT_DATE=$(date +"%Y%m%d_%H%M%S")
 
echo "[run the docker bench security script for the running container excluding the ecs agent container]"
cd docker-bench-security && sh docker-bench-security.sh -x agent > "dockerBenchSecurity-$CURRENT_DATE.txt"
 
# echo -e "\n\n\n-------------DIFFERENCE REPORT-------------" >> "dockerBenchSecurity-$CURRENT_DATE.txt"
# diff SNAPSHOT.txt dockerBenchSecurity-$CURRENT_DATE.txt >> "dockerBenchSecurity-$CURRENT_DATE.txt"
echo "[Report Generated as dockerBenchSecurity-$CURRENT_DATE.txt]"
